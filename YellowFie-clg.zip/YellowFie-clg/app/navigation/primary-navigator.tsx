/**
 * This is the navigator you will modify to display the logged-in screens of your app.
 * You can use RootNavigator to also display an auth flow or other user flows.
 *
 * You'll likely spend most of your time in this file.
 */
import React from "react"
import { createStackNavigator } from "@react-navigation/stack"
// import { WelcomeScreen, DemoScreen } from "../screens"
import {
  WelcomeScreen,
  CreateFeedScreen,
  ExploreScreen,
  DemoScreen,
  GalleryPagingScreen,
  MainScreen,
  FeedItemScreen,
  ImageItemScreen,
} from "../screens"



export type PrimaryParamList = {
  welcome: undefined
  demo: undefined
  feedItemScreen:undefined
  mainScreen:undefined
  gallery:undefined
  explore:undefined
  createFeedScreen:undefined
  imageitem:undefined
  

}

// Documentation: https://reactnavigation.org/docs/stack-navigator/
const Stack = createStackNavigator<PrimaryParamList>()

export function PrimaryNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        gestureEnabled: true,
      }}
    >
      <Stack.Screen name="welcome" component={WelcomeScreen} />
      <Stack.Screen name="demo" component={DemoScreen} />
      <Stack.Screen name="feedItemScreen" component={FeedItemScreen} />
      <Stack.Screen name="mainScreen" component={MainScreen} />
      {/* <Stack.Screen name="gallery" component={GalleryPagingScreen} /> */}
      <Stack.Screen name="explore" component={ExploreScreen} />
      <Stack.Screen name="createFeedScreen" component={CreateFeedScreen} />
      <Stack.Screen name="imageitem" component={ImageItemScreen} />
      <Stack.Screen name="gallery" component={GalleryPagingScreen} />
    </Stack.Navigator>
  )
}

/**
 * A list of routes from which we're allowed to leave the app when
 * the user presses the back button on Android.
 *
 * Anything not on this list will be a standard `back` action in
 * react-navigation.
 *
 * `canExit` is used in ./app/app.tsx in the `useBackButtonHandler` hook.
 */
const exitRoutes = ["welcome"]
export const canExit = (routeName: string) => exitRoutes.includes(routeName)
