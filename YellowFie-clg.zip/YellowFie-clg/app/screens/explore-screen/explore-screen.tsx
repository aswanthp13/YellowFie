import React,{useState,useEffect} from "react"
import { ViewStyle,ScrollView,View ,StyleSheet,TextStyle} from "react-native"
import { Screen,Header,ImageGallery } from "../../components"
import Chip from 'react-native-chip/SelectableChips'
// import { useNavigation } from "@react-navigation/native"
// import { useStores } from "../../models"
import { color ,spacing} from "../../theme"

const ROOT: ViewStyle = {
  backgroundColor: color.palette.white,
  flex: 1,
}
const BOLD: TextStyle = { fontWeight: "bold" }
const HEADER: TextStyle = {
  paddingTop: spacing[3],
  paddingBottom: spacing[5] - 1,
  paddingHorizontal: 0,
  backgroundColor: color.palette.white,
  // marginLeft:20, 
  fontFamily:"Mulish",
  marginBottom:1,
}

const HEADER_TITLE: TextStyle = {
  ...BOLD,
  fontSize: 12,
  lineHeight: 15,
  textAlign: "center",
  letterSpacing: 1.5,
  color: color.palette.black,
}

const CategoryButtonView :ViewStyle = {
  width:"95%",
  alignItems:"center",
  justifyContent:"center",
 

  // flexDirection: 'row',
  // alignItems: "center",
  // display:"flex",
  // marginTop: 16,
  // marginLeft: 8,
  // marginRight: 8
}
const chipsStyle = {
  border: 1,
  width: 100,
  // alignItems: "center",
  display: "flex",
  // marginHorizontal:16,
  backgroundColor: color.palette.white,
  borderWidth: 1,
  borderColor: '#EEEEEE',
 
  // marginTop:18
}
const chipsText = {
  fontSize: 12,
  textAlign: "center",
  color: color.palette.black,
  // fontFamily: 'Mulish',
}
const chipsStyleSelected = {
  // marginLeft: 16,
  width: 100,
  // marginHorizontal:16,
  border: 1,
  backgroundColor: color.palette.black,
  borderWidth: 1,
  borderColor: '#EEEEEE',
}
const valuesStyleSelected = {
  fontSize: 12,
  textAlign: "center",
  color: color.palette.white,
  fontFamily: 'Mulish',
}

export const ExploreScreen =(props)=> {
  
  const [data,setData]=useState(
    {url:"https://jsonplaceholder.typicode.com/photos?_limit=12&_page="}
    )

    const [categoryName, setCategoryName] = useState([])
    const [categoryTypes, setCategoryTypes] = useState([{}])

    useEffect(() => {
      getCategoryType()
    }, [])

    const onChangeChipsHandle = (categories) => {
      console.log("chips", categories)
  
      // let ids = [], id
      // if (categories.length > 0) {
      //   categories.map((data) => {
      //     id = categoryTypes.filter((item) => item.name === data)
      //     if (id.length > 0) {
      //       ids.push(id[0].id)
      //       // setTypeIds(ids)
      //     }
      //   })
  
      // }
  
      // // console.log("typeIds",typeIds)
      // console.log("categories", categories)
      // console.log("ids", ids)
  
    }

    const getCategoryType = async () => {

      const types = [
        {
          name: "Dress",
          id: "1"
        },
        {
          name: "Tops",
          id: "2"
        },
        {
          name: "Bottom",
          id: "3"
        },
        {
          name: "Accessories",
          id: "4"
        },
        {
          name: "ActiveWear",
          id: "5"
        }
      ];
  
      setCategoryTypes(types)
      setCategoryName(types.map((item, index) => item.name))
      console.log("categoryName", categoryName)
      console.log("types", categoryTypes)
  
      // let result
      // setImage("")
      // setIsLoading(true)
      // setUser({})
      // try {
      //   const demo = new Api()
      //   demo.setup()
      //   result = (await demo.getUser())
      // } catch (error) {
      //   setIsLoading(false)
      //   console.log("try catch error", error)
      // }
      // if (result.kind == "ok") {
      //   setIsLoading(false)
      //   console.log("result", result)
      //   setImage(result.user.imageUrl)
      //   setUser(result.user)
  
      //   return
      // } else {
      //   console.log("result error", result.kind)
  
      // }
    }

  return (
    <Screen style={ROOT} preset="scroll">
       <Header 
        headerTx={"ExploreScreen.HowTo"}
        style={HEADER}
        titleStyle={HEADER_TITLE}
      />

     
           <View style={CategoryButtonView}>
            <Chip
              chipStyle={chipsStyle}
              valueStyle={chipsText}
              valueStyleSelected={valuesStyleSelected}
              chipStyleSelected={chipsStyleSelected}
              initialChips={categoryName}
              onChangeChips={(chips) => onChangeChipsHandle(chips)}
              alertRequired={false} />
          </View>

          <View style={styles.container}>
             <ImageGallery source={data.url}/>
          </View> 
       
   
   </Screen>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EEEEEE',
    marginBottom:10,
    marginTop:20,
  },
});