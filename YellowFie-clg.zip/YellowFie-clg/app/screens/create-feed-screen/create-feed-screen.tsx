import React, { useState} from 'react'
import { ViewStyle, TextStyle,Image,View,ScrollView,Alert, TouchableOpacity,StyleSheet } from 'react-native'
import { Screen,  Header ,Button,Plusbutton,Text,DescriptionBox } from "../../components"
import { color, spacing, typography } from "../../theme"
import { useNavigation } from "@react-navigation/native"
import { observer } from "mobx-react-lite"
import * as ImagePicker from 'expo-image-picker'


const ROOT: ViewStyle = {
  backgroundColor: color.palette.white,
  flex: 1,
  margin:20,
  alignItems:"center",
  justifyContent:"center",
}

const BOLD: TextStyle = { fontWeight: "bold" }
const HEADER: TextStyle = {
  paddingTop: spacing[3],
  paddingBottom: spacing[5] - 1,
  paddingHorizontal: 0,
  backgroundColor: color.palette.white,
  marginLeft:20,
  
  
}

const HEADER_TITLE: TextStyle = {
  ...BOLD,
  fontSize: 12,
  lineHeight: 15,
  textAlign: "center",
  letterSpacing: 1.5,
  color: color.palette.black,
}

const StoreButtonView = {
  marginTop: 30,
  marginBottom:30,
  width:318,
  // alignItems: 'center',
  // justifyContent: 'center',
  
}

const StoreButton = {
  border: 1,
  backgroundColor: color.palette.white,
  // borderWidth: 1,
  // borderColor: color.palette.black,
  marginLeft: 24,
  marginRight: 24,
  height: 48,
  shadowColor: color.palette.white,
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 2,
  elevation: 4
}
const StoreButtonText = {
  fontFamily: typography.secondary,
  fontSize: 16,
  // textAlign: "center",
  color: color.palette.black,
  // fontFamily: 'Mulish',

}
// const AddImage= ()=>{
//   Alert.alert("Image Add")

// }


const ButtonClick= ()=>{
  Alert.alert("Button Pressed")

}
const ViewComponent = {
  flex: 1
}

export const CreateFeedScreen = observer(function CreateFeedScreen() {
  const navigation = useNavigation()
  const goBack = () => navigation.goBack()

 
  const [image, setImage] = useState(null)

  const pickImage = async () => {
    const { status } = await ImagePicker.requestCameraRollPermissionsAsync()
        if (status !== 'granted') {
          Alert.alert('Sorry, we need camera roll permissions to make this work!')
        }
        else{
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log(result)

    if (!result.cancelled) {
      setImage(result.uri)
    }}
  };

  return (
    <Screen style={ROOT} preset="scroll">
      
             

             <Header 
        headerTx={"CreateFeedScreen.HowTo"}
        leftIcon="back"
        onLeftPress={goBack}
        style={HEADER}
        titleStyle={HEADER_TITLE}
      />

<ScrollView   showsVerticalScrollIndicator ={false}>
      <View style={ViewComponent}>
        <View  style={styles.container}>
        
           {image ? 
                 < View >
                  {image && <Image source={{ uri: image }} style={{ width: 320, height: 320 }} />} 
                  </ View>
                 
                  : <TouchableOpacity  onPress={pickImage}><Plusbutton/></TouchableOpacity> }
      </View>

      <View style={{ marginTop: 30,}}>
        <Text style={{textAlign:"left"}}>Description</Text>
        <DescriptionBox   placeholder={"Description" }/>
      </View>

      <View style={StoreButtonView}>
        <Button style={StoreButton}
          textStyle={StoreButtonText}
          tx={"CreateFeedScreen.button"}
          onPress={ButtonClick} >
        </Button>
      </View>
      
      </View>

      </ScrollView>
    </Screen>
  )
})

const styles = StyleSheet.create({

  text:{
    fontWeight:"400",
    fontSize:12,
    lineHeight:15.06,
  },
  header: {
    marginTop: 20,
    justifyContent: "center",
    textAlign: "center",
  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
    // width: 320
  },
  img: {
    // marginTop: 20,
    width: 20,
    height: 20
  },
  btn: {
    paddingTop: 50,
    paddingBottom: 50,
    paddingRight: 100,
    paddingLeft: 100,
    borderWidth: 0.5,
    borderColor: '#B4B4B4',
  },
  storeInput: {
    width: 320,
    // height: 44,
    borderColor: "#B4B4B4",
    borderWidth: 1,
    marginTop: 10,
    fontFamily:"Mulish",
    color:"black",
    
    
  },
  updatebtn: {
  // width: 480,
  // marginLeft: 20,
    borderWidth: 1,
    backgroundColor: color.palette.white,
    borderColor: '#B4B4B4',
    marginLeft: 24,
    marginRight: 24,
    height: 48,
    shadowColor: color.palette.white,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 4
  }
  
     
  })
