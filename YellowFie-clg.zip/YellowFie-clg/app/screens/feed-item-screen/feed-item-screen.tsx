import React, { useState,useEffect } from 'react'
import { ViewStyle, TextStyle,Image ,ImageStyle, View,ScrollView,Alert, TouchableOpacity,TextInput,StyleSheet } from 'react-native'
import { Screen, Text, Header,FeedItem } from "../../components"
import { color, spacing, typography } from "../../theme"
import { useNavigation } from "@react-navigation/native"



  const BOLD: TextStyle = { fontWeight: "bold" }
const HEADER: TextStyle = {
  paddingTop: spacing[3],
  paddingBottom: spacing[5] - 1,
  paddingHorizontal: 0,
  backgroundColor: color.palette.white,
  marginLeft:20,
  
  
}

const HEADER_TITLE: TextStyle = {
  ...BOLD,
  fontSize: 12,
  lineHeight: 15,
  textAlign: "center",
  letterSpacing: 1.5,
  color: color.palette.black,
}
  


export const FeedItemScreen = (props) => {
  
    const navigation = useNavigation()
    const goBack = () => navigation.goBack()

  const [data, setData] = useState(
    [
      {id:1,
    storename:"Amazing Boutique ",
    location:"Location",
    city:"city",
    count:75011,
    productname:"BRIGITTE BRIANNA RUFFLE SKIrt",
    comments:19
  },
  {id:2,
    storename:"Amazing Boutique ",
    location:"Location",
    city:"city",
    count:75011,
    productname:"BRIGITTE BRIANNA RUFFLE SKIrt",
    comments:20
  },
  {id:3,
    storename:"Amazing Boutique ",
    location:"Location",
    city:"city",
    count:75011,
    productname:"BRIGITTE BRIANNA RUFFLE SKIrt",
    comments:18
  },
  // {id:2,
  //   storename:"Amazing Boutique ",
  //   location:"Location",
  //   city:"city",
  //   count:75011,
  //   productname:"BRIGITTE BRIANNA RUFFLE SKIrt",
  //   comments:"View 19 comments"
  // },
  // {id:3,
  //   storename:"Amazing Boutique ",
  //   location:"Location",
  //   city:"city",
  //   count:75011,
  //   productname:"BRIGITTE BRIANNA RUFFLE SKIrt",
  //   comments:"View 19 comments"
  // },

]
  
  
  );


  
   

    return (
    
  <View style={{justifyContent: 'center', alignItems: 'center',}}>
  <Header
               headerText="Feed"
               leftIcon="back"
               onLeftPress={goBack}
               style={HEADER}
               titleStyle={HEADER_TITLE}
             />

<ScrollView>


    {data.map((el,id) => {return   (

      
      <FeedItem  data={el} />
      
      )}) }

</ScrollView>
  </View>

      
    )
}










