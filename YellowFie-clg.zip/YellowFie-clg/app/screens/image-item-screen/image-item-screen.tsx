import React,{useState} from "react"
import { ViewStyle } from "react-native"
import { Screen, Text,ImageItemData } from "../../components"
// import { useNavigation } from "@react-navigation/native"
// import { useStores } from "../../models"
import { color } from "../../theme"

const ROOT: ViewStyle = {
  backgroundColor: color.palette.white,
  flex: 1,
  alignItems: 'center',
  justifyContent: 'center',
}

export const ImageItemScreen = ()=> {
  
const [data,setData]=useState({url:"https://bit.ly/3hir8Yx"})

  return (
    <Screen style={ROOT} preset="scroll">
     <ImageItemData source={data}/>
    </Screen>
  )
}
