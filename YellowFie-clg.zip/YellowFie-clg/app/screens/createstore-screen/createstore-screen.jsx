
import React, { useState, useEffect } from "react"
import { observer } from "mobx-react-lite"
import { ViewStyle, View, StyleSheet } from "react-native"
import { Screen, Header, Plusbutton, TextField, Button, Text } from "../../components"
import { color, typography } from "../../theme"
import { useNavigation } from "@react-navigation/native"

const ROOT  = {
  backgroundColor: color.palette.white,
  flex: 1,
}
const CONTAINER = {
  justifyContent: "center",
}

const BOLD = { fontWeight: "bold" }

// const TEXT = {
//   fontFamily: typography.primary,
//   fontSize: 14,
//   color: color.primary,
// }
const StoreButtonView = {
  marginTop: 70
}

const StoreButton = {
  border: 1,
  backgroundColor: color.palette.white,
  // borderWidth: 1,
  // borderColor: color.palette.black,
  marginLeft: 24,
  marginRight: 24,
  height: 48,
  shadowColor: color.palette.white,
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.8,
  shadowRadius: 2,
  elevation: 4
}
const StoreButtonText = {
  fontFamily: typography.secondary,
  fontSize: 16,
  fontFamily:"Mulish",
  textAlign: "center",
  color: color.palette.black,
  // fontFamily: 'Mulish',

}

const HEADER = {
  fontFamily:"Mulish"
  // shadowColor: color.palette.white,
  // shadowOffset: { width: 0, height: 1 },
  // shadowOpacity: 0.8,
  // shadowRadius: 0,
  // elevation: 1,
  // borderBottomWidth: 1,
  // borderBottomColor: "#B4B4B4"
}

const HEADER_TITLE = {
  fontSize: 16,
  textAlign: "center",
  letterSpacing: 1.5,
  color: color.palette.black,
  fontFamily:"Mulish"
}

const ViewComponent = {
  flex: 1
}

export const CreateStoreScreen = observer(function CreateStoreScreen() {
  const navigation = useNavigation()
  const goBack = () => navigation.goBack()

  const [showHeaderTitle, setHeaderTitle] = useState("Store Details")

  const storeUpdateProps = () => {
    console.log("props")
    setHeaderTitle("CreateStoreScreen.StoreTitle")
  }

  useEffect(() => {
    setHeaderTitle("CreateStoreScreen.StoreTitle")
  })

  return (
    <Screen style={ROOT} preset="scroll">
      <Header storeUpdateProps={storeUpdateProps}
        headerTx={"CreateStoreScreen.HowTo"}
        leftIcon="back"
        onLeftPress={goBack}
        style={HEADER}
        titleStyle={HEADER_TITLE}
      />
      <View style={ViewComponent}>
      <View style={styles.container}>
        <Plusbutton />
        {/* <Plusbutton/> */}
      </View>
      <View style={{ marginTop: 30, marginLeft: 20 }}>
        <Text>Store Name</Text>
        <TextField placeholder="Store Name" style={styles.storeInput}/>
      </View>
      {/* <View style={{ marginTop: 120, }}>
        <Button title="Update Store details" style={styles.updatebtn} />
      </View> */}
      <View style={StoreButtonView}>
        <Button style={StoreButton}
          textStyle={StoreButtonText}
          tx={"CreateStoreScreen.button"}>
        </Button>
      </View>
      </View>
    </Screen>
  )
})

const styles = StyleSheet.create({
  header: {
    marginTop: 20,
    justifyContent: "center",
    textAlign: "center",
  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
    // width: 320
  },
  img: {
    // marginTop: 20,
    width: 20,
    height: 20
  },
  btn: {
    paddingTop: 50,
    paddingBottom: 50,
    paddingRight: 100,
    paddingLeft: 100,
    borderWidth: 0.5,
    borderColor: '#B4B4B4',
  },
  storeInput: {
    width: 320,
    // height: 44,
    borderColor: "#B4B4B4",
    borderWidth: 1,
    marginTop: 10,
    fontFamily:"Mulish"
  },
  updatebtn: {
  // width: 480,
  // marginLeft: 20,
    borderWidth: 1,
    backgroundColor: color.palette.white,
    borderColor: '#B4B4B4',
    marginLeft: 24,
    marginRight: 24,
    height: 48,
    shadowColor: color.palette.white,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 4
  }
})