import React ,{useState,useEffect} from "react"
import { ViewStyle } from "react-native"
import { Screen, Text,AddressItem ,} from "../../components"

// import { useNavigation } from "@react-navigation/native"
import { color } from "../../theme"

const ROOT: ViewStyle = {
  backgroundColor: color.palette.white,
  alignItems:"center",
  justifyContent:"center",
  flex: 1,
}

export const MainScreen=()=> {
  const [data,setData]=useState(
    
    
    {  
      name:"John Usermock",
      addressline1:"Addressline1",
      addressline2:"Addressline2",
      city:"City",
      state:"State",
      totalamount:66600
    },
  
  
  )
  return (
    <Screen style={ROOT} preset="scroll">
      {/* <Text preset="header" text="mainScreen" /> */}
      <AddressItem data={data}/>
    </Screen>
  )
}
