import * as React from "react"
import * as ImagePicker from 'expo-image-picker';
import {storage} from './firebaseServices';
import { TextStyle, View, ViewStyle } from "react-native"
import { observer } from "mobx-react-lite"
import { color, typography } from "../../theme"
import { Text } from "../../components"

const CONTAINER = {
  justifyContent: "center",
}

const TEXT = {
  fontFamily: typography.primary,
  fontSize: 14,
  color: color.primary,
}
export const PickImage = async (type) => {
  switch (type) {
    case 'Camera':
      let resultCam = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.All,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });
      if (!resultCam.cancelled) {
        return resultCam;
      }

    case 'Storage':
      let resultStr = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.All,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });
      // console.log(result);
      if (!resultStr.cancelled) {
        return resultStr;
      }
    default:
      break;
  }
}



/**
 * Describe your component here
 */
export const ImageUpload =  async(uri)  => {
  let data = await fetch(uri);
  let blob = await data.blob();
  let filename = Math.floor(Math.random() * 10000000);

  const uploadImg = await storage.ref(`post/${filename}.jpg`).put(blob);
  console.log(uploadImg);
  const url = await storage.ref(`post`).child(`${filename}.jpg`).getDownloadURL();
  console.log(url, 'url');


  return url;
}
