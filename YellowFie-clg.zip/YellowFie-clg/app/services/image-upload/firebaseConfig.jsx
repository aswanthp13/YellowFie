module.exports = firebase = {
    apiKey: "AIzaSyDCHh4D3nHXZs8vBBs8cJ9AcRgZtNoXy7U",
    authDomain: "online-shopping-17bb4.firebaseapp.com",
    databaseURL: "https://online-shopping-17bb4.firebaseio.com",
    projectId: "online-shopping-17bb4",
    storageBucket: "online-shopping-17bb4.appspot.com",
    messagingSenderId: "4043412489",
    appId: "1:4043412489:web:14b4c0b6a3c513ba9bd4d8"
}

module.exports = credential = {
    "type": "service_account",
    "project_id": "online-shopping-17bb4",
    "private_key_id": "1c68739e5c26c2b02e49f16cf56e7692b68d60bf",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCRPEsULOX9/qlv\ngJyj2r/ZxY+/R11SFqRCzTMFALhwoMBQY+jABryREEYPk51epaVB9OwIqGF8jq8r\n3WFRVlPLfT5T9wfPc444viQ/2V0UrZSkZ3KNIZzX0wHfgDx7lsA1+li5dQIVLnvj\njTuFZyzPdPQX31KJxp7XkDPxH3UZ35c38SXTMT5jdbN2TWfK5ato9YuEaHiclGjZ\n0Of5kDKorzm1tQimAsOuBd3bsDZ3SrcbznnggdMElHkMdHkAFfCVC/J6jGdB7AxJ\nLFtZ9ySC5YqradCWj0yzyvY52XpZZIeyrcquYgGDwB5Km6n9yGuH6qgpl1DfpMj3\ncArAHijvAgMBAAECggEAN0u1aiEOD/59lC5rdRc8JDXL3Q/WwAJO2AA4hJcZoggS\nMIlZfIMUGEcR5axWJkr6+Hm/xCwXsczBdPn8q3MqxDcTG/TZzGo6o/AA7S5c+hp8\nlXutaX56sNFtzSKN5KAo3mRKk5GxEU95a9HB77CwpuvoY45rZnlw0LHelNddRlP/\n7YEg6GIrPKAD6EcucYG2DrAxEQwBoPMUY9/uXC9eHQ5CX+KUu1cPX0j7u7D7r5VR\nUv89BZp/qYOOXnz617MHM6NHjc3e1TuBnft1GwSKjB1k9e8KaiyUFj43uyPVCUvw\nTfPSQr5diWtRV6Z0mhgKLdRzUIO6ufiXX1PQtl/FgQKBgQDEGo09qb2+LFLhOzD1\nUWnfb4RQfHfl46586ECEHXgDCz7F63y17jP7/AXOTVdSb8bCruJWstJi/48ca7fW\nnsQbRPtNhWljrIFmM8kM1NLLUZyJImTfAkNMlv90szidETEWnvsCU33lqD9tUvBx\ncFoFcyMBJwvP7LQEiiTFvDD6ZwKBgQC9mFTnKVZogeAWMCnBwSK/P43106+0Ur7M\nRbs2LrAWiTQMjiuiw9WQjl/6fwhMBA7SHSMhE6vvsPDC9SkLjjzqLJUAtY2V0GgI\nuby9VylhT7yPacntIncw63FSz1AEIlppgaPXot3eOCjXBWC7n+7jb31cRLWThalD\nkOILs+VYOQKBgEZHebzSm0SPX/iGHQqd7cJ8lb++i72gtkTfe1edtAfrPMjzlxMg\nVhMFhBMmVpgdpO7afBU0Kv/9tI0r8YuCBKf9Nc7XdCibhxhYkMH/d7gT/HSNFfdy\nOSo2p0BshmqL4brIqQ5xW5o1jN2iLreI20o+tBnSo4IVw4Io+/q9chQbAoGANFJj\nq9+GjxS4aKcl/uhz1F+Pp7WhmZv0N59OyOcdhTqb+JMLi8GLoHcKGbEQ8xlzlZyg\n4zHwkxc7ejH5/8xjFyTygd2Yky2OaEoJwh7ZtpcwrEs/hIesaP2wqm+330wzs0Yp\nlwrFO9w3uQ8s4NqELJPJ/rqfeXS7f3/uQdiFhFECgYA0kLZqWdPnSAvcD5mf7e6H\n+q3oqYY1sFfzclnGV6pTqXoamumklQuELH/HyW0zaPz+AlNRf0RkZSQE4IxSFLmy\ngzBBAYKi7QrdTWipwunBJAnoJEY/sS/6Gnq2jQe0TBeYv4EdEOrRyD6rgHiwt7sU\nsKAPqXaSt1yKK6DngRRhYg==\n-----END PRIVATE KEY-----\n",
    "client_email": "firebase-adminsdk-wha4b@online-shopping-17bb4.iam.gserviceaccount.com",
    "client_id": "106288667555609298092",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-wha4b%40online-shopping-17bb4.iam.gserviceaccount.com"
}
