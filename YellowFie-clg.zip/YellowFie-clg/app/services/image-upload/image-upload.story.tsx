import * as React from "react"
import { storiesOf } from "@storybook/react-native"
import { StoryScreen, Story, UseCase } from "../../../storybook/views"
import { color } from "../../theme"
import { ImageUpload } from "./image-upload"

storiesOf("ImageUpload", module)
  .addDecorator(fn => <StoryScreen>{fn()}</StoryScreen>)
  .add("Style Presets", () => (
    <Story>
      <UseCase text="Primary" usage="The primary.">
        <ImageUpload style={{ backgroundColor: color.error }} />
      </UseCase>
    </Story>
  ))
