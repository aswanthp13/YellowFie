import firebase from 'firebase/app';
import "firebase/storage";

const firebaseConfig = {

  apiKey: "AIzaSyCVLUrpcyL_k0Mx0AqI-uX6EF6C74iaQoI",

  authDomain: "yellowfie-app.firebaseapp.com",

  databaseURL: "https://yellowfie-app.firebaseio.com",

  projectId: "yellowfie-app",

  storageBucket: "yellowfie-app.appspot.com",

  messagingSenderId: "184829817514",

  appId: "1:184829817514:web:5b2199b12c00e49e9a96d3",

  measurementId: "G-BGHFWEG4C0"

};

firebase.initializeApp(firebaseConfig);


const storage = firebase.storage();



export { storage, firebase as default };