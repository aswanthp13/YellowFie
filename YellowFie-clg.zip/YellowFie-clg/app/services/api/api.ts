import { CartDetails } from './../../components/cart-details/cart-details';
import { ApisauceInstance, create, ApiResponse } from "apisauce"
import { getGeneralApiProblem } from "./api-problem"
import { ApiConfig, DEFAULT_API_CONFIG } from "./api-config"
import * as Types from "./api.types"
import { AsyncStorage } from 'react-native';

/**
 * Manages all requests to the API.
 */
export class Api {
  /**
   * The underlying apisauce instance which performs the requests.
   */
  apisauce: ApisauceInstance

  /**
   * Configurable options.
   */
  config: ApiConfig

  /**
   * Creates the api.
   *
   * @param config The configuration to use.
   */
  constructor(config: ApiConfig = DEFAULT_API_CONFIG) {
    this.config = config
  }

  /**
   * Sets up the API.  This will be called during the bootup
   * sequence and will happen before the first React component
   * is mounted.
   *
   * Be as quick as possible in here.
   */
  token = async () => await AsyncStorage.getItem("token")
  setup() {
    // construct the apisauce instance
    this.apisauce = create({
      baseURL: this.config.url,
      timeout: this.config.timeout,
      headers: {
        Accept: "application/json",
        Authorization: this.token
      },
    })
  }

  /**
   * Gets a list of users.
   */
  async getUsers(): Promise<Types.GetUsersResult> {

    // make the api call
    const response: ApiResponse<any> = await this.apisauce.get(`/users`)

    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }

    const convertUser = (raw) => {
      return {
        id: raw.id,
        name: raw.name,
      }
    }

    // transform the data into the format we are expecting
    try {
      const rawUsers = response.data
      const resultUsers: Types.User[] = rawUsers.map(convertUser)
      return { kind: "ok", users: resultUsers }
    } catch {
      return { kind: "bad-data" }
    }
  }

  /**
   * Gets a single user by ID
   */

  // async getUser(id: string): Promise<Types.GetUserResult> {
  //   // make the api call
  //   const response: ApiResponse<any> = await this.apisauce.get(`/users/${id}`)

  //   // the typical ways to die when calling an api
  //   if (!response.ok) {
  //     const problem = getGeneralApiProblem(response)
  //     if (problem) return problem
  //   }

  //   // transform the data into the format we are expecting
  //   try {
  //     const resultUser: Types.User = {
  //       id: response.data.id,
  //       name: response.data.name,
  //     }
  //     return { kind: "ok", user: resultUser }
  //   } catch {
  //     return { kind: "bad-data" }
  //   }
  // }

  async getUser(): Promise<Types.GetUserResult> {
    // make the api call
    const response: ApiResponse<any> = await this.apisauce.get(`v1/user`)

    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }

    // transform the data into the format we are expecting
    try {
      const resultUser: Types.UserRes = {
        user: response.data.user,
        success: response.data.success

      }
      return { kind: "ok", user: resultUser.user }
    } catch {
      return { kind: "bad-data" }
    }

  }

  async login(body): Promise<Types.SignInResult> {
    console.log("body", body)
    // let request = create({
    //   baseURL: this.config.url,
    //   timeout: this.config.timeout,
    //   data: body, 
    //     headers: {
    //     Accept: "application/json",
    //   },
    // })
    // console.log("Api request",request)
    // make the api call
    const response: ApiResponse<any> = await this.apisauce.post(`v1/user/login`, body = body)



    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }

    // transform the data into the format we are expecting
    try {
      const resultUser: Types.LoginRes = {
        user: response.data
      }
      return { kind: "ok", user: resultUser }
    } catch {
      return { kind: "bad-data" }
    }
  }

  // get products for the store used in storePageScreen
  async getProducts(): Promise<Types.GetProductsResult> {
    let token = await AsyncStorage.getItem('token')
    this.apisauce.setHeaders({
      Authorization: token,
      Accept: "application/json",
    })
    const response: ApiResponse<any> = await this.apisauce.get(`/v1/products`)

    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }
    try {
      const resultProducts: Types.Products = {
        productsData: response.data,
      }
      return { kind: "ok", products: resultProducts }
    } catch {
      return { kind: "bad-data" }
    }
  }


  // get product based on Single product ID
  async getProduct(id: string): Promise<Types.GetProductResult> {
    // make the api call
    let token = await AsyncStorage.getItem('token')
    this.apisauce.setHeaders({
      Authorization: token,
      Accept: "application/json",
    })
    const response: ApiResponse<any> = await this.apisauce.get(`/v1/product/${id}`)

    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }
    console.log("Apiservice getProduct")

    // transform the data into the format we are expecting
    try {
      const resultUser: Types.Product = {
        productData: response.data,
      }
      return { kind: "ok", product: resultUser }
    } catch {
      return { kind: "bad-data" }
    }
  }

  // get feeds data based on userId
  async getFeed(id: string): Promise<Types.GetFeedResult> {
    // make the api call
    const response: ApiResponse<any> = await this.apisauce.get(`/v1/feed/:${id}`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWZiNGQyOThmOTIxMjQ0MmE0NTg1NmEzIiwiaWF0IjoxNjA1OTU1MTAxLCJleHAiOjE2MDU5NjUxMDF9.xxuWC0rTu8xqNE5wDKlzyrgN8QaAhFCMN5-HD4CiPx8",
      },
    })

    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }
    console.log("Apiservice getFeeds")

    // transform the data into the format we are expecting
    try {
      const resultFeed: Types.Feed = {
        FeedData: response.data,
      }
      return { kind: "ok", feed: resultFeed }
    } catch {
      return { kind: "bad-data" }
    }
  }

  //get comments based on feed id from feeds
  async getComments(id: string): Promise<Types.GetCommentsResult> {
    // make the api call
    const response: ApiResponse<any> = await this.apisauce.get(`/v1/comments/:${id}`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWZiNGQyOThmOTIxMjQ0MmE0NTg1NmEzIiwiaWF0IjoxNjA1OTU1MTAxLCJleHAiOjE2MDU5NjUxMDF9.xxuWC0rTu8xqNE5wDKlzyrgN8QaAhFCMN5-HD4CiPx8",
      },
    })

    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }
    console.log("Apiservice getFeeds")

    // transform the data into the format we are expecting
    try {
      const resultComments: Types.Comments = {
        CommentsData: response.data,
      }
      return { kind: "ok", comments: resultComments }
    } catch {
      return { kind: "bad-data" }
    }
  }

  // Get Trials for the list
  async getTrials(): Promise<Types.GetTrialsResult> {
    // make the api call
    let token = await AsyncStorage.getItem('token')
    this.apisauce.setHeaders({
      Authorization: token,
      Accept: "application/json",
    })
    const response: ApiResponse<any> = await this.apisauce.get(`/v1/trailorders`)

    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)

      if (problem)

        return problem
    }
    console.log("Apiservice getTrials")

    // transform the data into the format we are expecting
    try {
      const resultTrials: Types.Trials = {
        TrialsData: response.data,
      }
      return { kind: "ok", trials: resultTrials }
    } catch {
      return { kind: "bad-data" }
    }
  }

  // Get Trial based on Item
  async getTrial(id: string): Promise<Types.GetTrialResult> {
    // make the api call

    let token = await AsyncStorage.getItem('token')
    this.apisauce.setHeaders({
      Authorization: token,
      Accept: "application/json",
    })
    const response: ApiResponse<any> = await this.apisauce.get(`/v1/trailorder/${id}`)
    console.log("ID", id)

    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }


    // transform the data into the format we are expecting
    try {
      const resultTrial: Types.Trial = {
        TrialData: response.data,
      }
      return { kind: "ok", trial: resultTrial }
    } catch {
      return { kind: "bad-data" }
    }
  }
  async userAvailability(name: string): Promise<Types.GetUniqueUserResult> {
    // make the api call

    const response: ApiResponse<any> = await this.apisauce.get(`/v1/uniqueUser/${name}`)
    console.log("username", name)

    // the typical ways to die when calling an api
    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }


    // transform the data into the format we are expecting
    try {
      const resultUniqueuser: Types.UniqueUser = {
        Uniqueuser: response.data,
      }
      return { kind: "ok", uniqueName: resultUniqueuser }
    } catch {
      return { kind: "bad-data" }
    }
  }
  async getAddress(): Promise<Types.GetAddressResult> {

    const response: ApiResponse<any> = await this.apisauce.get(`/v1/address`)

    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }
    try {
      const resultAddress: Types.Address = {
        AddressData: response.data,
      }
      return { kind: "ok", address: resultAddress }
    } catch {
      return { kind: "bad-data" }
    }
  }
  // post default address for the checkout screen
  async setDefaultaddress(id: string): Promise<Types.DefaultaddressResult> {

    const response: ApiResponse<any> = await this.apisauce.post(`/v1/defaultAddress`)

    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }
    try {
      const resultDefaultaddress: Types.DefaultAddress = {
        defaultAddressData: response.data,
      }
      return { kind: "ok", defaultaddress: resultDefaultaddress }
    } catch {
      return { kind: "bad-data" }
    }
  }
  // add the product to cart
  async AddToCart(body): Promise<Types.AddToCartResult> {
    let token = await AsyncStorage.getItem('token')
    this.apisauce.setHeaders({
      Authorization: token,
      Accept: "application/json",
    })

    const response: ApiResponse<any> = await this.apisauce.post(`/v1/cart`, body = body)

    if (!response.ok) {
      const problem = getGeneralApiProblem(response)
      if (problem) return problem
    }
    try {
      const resultDefaultaddress: Types.AddTocart = {
        CartData: response.data,
      }
      return { kind: "ok", cartData: resultDefaultaddress }
    } catch {
      return { kind: "bad-data" }
    }
  }


}

