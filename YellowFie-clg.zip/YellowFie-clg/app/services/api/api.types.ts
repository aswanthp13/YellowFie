import { GeneralApiProblem } from "./api-problem"

export interface UserRes {
  user: User
  success: boolean
}
export interface LoginRes {
 user:any
}


export interface User {
  _id: number
  name: string
  emailVerified:boolean
  active:boolean
  email:String
  imageUrl:String
  phone:String
  type:string
}

export interface Products {
  productsData:any
}
export interface Product {
  productData: any
}
export interface Feed {
  FeedData: any
}
export interface Comments {
  CommentsData: any
}

export interface Trials{
  TrialsData:any
}
export interface AddTocart{
  CartData:any
}

export interface Trial{
  TrialData:any
}
export interface UniqueUser{
  Uniqueuser:any
}
export interface Address{
  AddressData:any
}
export interface DefaultAddress{
  defaultAddressData:any
}

export type GetUsersResult = { kind: "ok"; users: User[] } | GeneralApiProblem
export type GetUserResult = { kind: "ok"; user: User } | GeneralApiProblem
export type GetProductsResult = { kind: "ok"; products: Products } | GeneralApiProblem
export type GetProductResult = { kind: "ok"; product: Product } | GeneralApiProblem
export type GetFeedResult = { kind: "ok"; feed: Feed } | GeneralApiProblem
export type GetCommentsResult = { kind: "ok"; comments: Comments } | GeneralApiProblem
export type SignInResult = { kind: "ok"; user: LoginRes } | GeneralApiProblem
export type GetTrialsResult = { kind: "ok"; trials: Trials } | GeneralApiProblem
export type GetTrialResult = { kind: "ok"; trial: Trial } | GeneralApiProblem
export type GetUniqueUserResult = { kind: "ok"; uniqueName: UniqueUser } | GeneralApiProblem
export type GetAddressResult = { kind: "ok"; address: Address } | GeneralApiProblem
export type DefaultaddressResult = { kind: "ok"; defaultaddress: DefaultAddress } | GeneralApiProblem
export type AddToCartResult = { kind: "ok"; cartData: AddTocart } | GeneralApiProblem

