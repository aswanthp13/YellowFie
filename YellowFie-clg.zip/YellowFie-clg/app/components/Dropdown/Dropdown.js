import React, { useState } from "react";
import { TextInput, StyleSheet, View, Text } from "react-native";
import { Picker } from "@react-native-picker/picker";


const DropDown = (props) => {
  const [selected, setselected] = useState('')
  return (
    <View style={[styles.main, props.inputStyle]}>
      <View style={[styles.container, props.containerStyle]}>
        <Text style={styles.title}>{props.title}</Text>
        <View style={{ borderWidth: 1, borderColor: 'silver' }}>
          <Picker
            selectedValue={props.value}
            style={[styles.input,]}
            {...props}
            onValueChange={(itemValue, itemIndex) =>
              props.onValueChange(props.category, itemValue,)
            }>

            {props.options && props.options.map((data,ind )=> (
              <Picker.Item key={ind} label={data.label} value={data.value} />
            ))}

          </Picker>

        </View>
        {props.error ? (
          <View style={styles.alert}>
            <Text style={styles.error1}>{props.error}</Text>
          </View>
        ) : null}
      </View>

    </View>
  );
};
export default DropDown;

const styles = StyleSheet.create({
  input: {
    borderColor: "silver",
    borderWidth: 1,
    color: "black",
    minHeight: 44,
    // backgroundColor:"transparent"
  },
  container: {
    justifyContent: "center",
    width: "100%",
    height: 100
  },

  error1: {
    color: "red",
    justifyContent: "center",
    alignItems: "center",
  },
  alert: {
    // marginLeft: 10
  },
  title: {
    marginTop: 1,
    marginBottom: 14
  }
});