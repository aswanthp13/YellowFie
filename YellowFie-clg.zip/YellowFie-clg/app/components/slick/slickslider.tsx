import React from 'react'
import { Dimensions, Image, StyleSheet,  View } from 'react-native';
import Slick from 'react-native-slick';
// const screenWidth = Dimensions.get('screen').width;
const screenHeight = Dimensions.get('screen').height;

export const SlickSlider = (props) => {
  
  
    return (
        <View style={{flex:1}}>
        <View style={styles.cont}>
             {props.images?
             <Slick style={styles.wrapper} >
                {props.images.map((data)=> (
                    <View style={styles.slide1}>
                        <Image source={{uri:'https://bit.ly/37CpI7H'}} style={{alignContent:"center", width:"100%",height:screenHeight/1.3}}  />
                   </View>
                 ))}
             </Slick>:
                 <Slick style={styles.wrapper} >
        <View style={styles.slide1}>
          <Image source={{uri:'https://bit.ly/37CpI7H'}} style={{ alignContent:"center", width:"100%",height:screenHeight/1.3}}  />
        </View>
        <View style={styles.slide1}>
        <Image source={{uri:'https://bit.ly/34t29Mz'}} style={{ alignContent:"center", width:"100%",height:screenHeight/1.3}}  />
        </View>
        <View style={styles.slide1}>
        <Image source={{uri:'https://bit.ly/2KDmIyZ'}} style={{ alignContent:"center", width:"100%",height:screenHeight/1.3}}  />
        </View>
        
      </Slick>
      
      }
        </View>
   </View>
    )
}



const styles = StyleSheet.create({
    cont:{
    height:screenHeight/2.2,
    width:"100%"
    },
    wrapper: {
        
    },
    slide1: {
      flex: 1,
      justifyContent: 'flex-start',
      alignItems: 'center',
      backgroundColor: 'white',
      alignContent:"center",

    },
   
    text: {
      color: '#fff',
      fontSize: 30,
      fontWeight: 'bold',
    }
})







