import React from "react";
import { View, Text, TextInput, StyleSheet, TextStyle } from "react-native";
import { translate } from "../../i18n"
import { mergeAll, flatten } from "ramda"

const INPUT: TextStyle = {
  height: 113,
  width:320,
  backgroundColor: 'transparent',
  color: 'grey',
  paddingHorizontal: 8,
  // borderRadius: 15,
  borderWidth:1,
  borderColor:"#B4B4B4",
  textAlignVertical : "top",
  // textAlign: 'left',
  // justifyContent: 'flex-start',
  // paddingBottom: 70,
}

const enhance = (style, styleOverride) => {
  return mergeAll(flatten([style, styleOverride]))
}

export  const DescriptionBox = (props) => {
  const {
    placeholderTx,
    placeholder,
    inputStyle: inputStyleOverride,
  } = props

  let inputStyle: TextStyle = INPUT
  inputStyle = enhance(inputStyle, inputStyleOverride)
  const actualPlaceholder = placeholderTx ? translate(placeholderTx) : placeholder
  return (
    <View style={styles.storeMain}>
      <TextInput
        // style={styles.TextBox}
        maxLength={300}
        multiline={true}
        numberOfLines={4}
        placeholder={actualPlaceholder}
        placeholderTextColor="grey"
        style={inputStyle}
      />
    </View>
  );
};



const styles = StyleSheet.create({
 
  storeMain: {
    paddingTop: 10,
  },

  // TextBox: {
  //   height: 113,
  //   width:320,
  //   backgroundColor: 'transparent',
  //   color: 'grey',
  //   paddingHorizontal: 8,
  //   // borderRadius: 15,
  //   borderWidth:1,
  //   borderColor:"#B4B4B4",
  //   textAlignVertical : "top",
  //   // textAlign: 'left',
  //   // justifyContent: 'flex-start',
  //   // paddingBottom: 70,
  // },
});
