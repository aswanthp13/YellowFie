export const icons = {
  back: require("./arrow-left.png"),
  bullet: require("./bullet.png"),
  cart:require("./cart.png")
}

export type IconTypes = keyof typeof icons
