import React, { useState, useEffect } from "react"
import { View, Image, Dimensions, Text, TouchableOpacity, StyleSheet } from "react-native"
import { observer } from "mobx-react-lite"
import { color, typography } from "../../theme"
import { useNavigation } from "@react-navigation/native"

const width = Dimensions.get("window").width
const height = Dimensions.get("window").height

const CONTAINER = {
  justifyContent: "center",
}

const TEXT = {
  fontFamily: typography.primary,
  fontSize: 14,
  color: color.primary,
}

/**
 * Describe your component here
 */
export const MySentTrialItem = observer(function MySentTrialItem(props) {
  const { style } = props
  const navigation = useNavigation()

  const openTrial = () =>{
    navigation.navigate("trialdetail",{id:props.item._id})
  }

  return (

    <TouchableOpacity style={[styles.item, style]} onPress={() => openTrial(props.item)}>

      <Image
        style={styles.tinyLogo}
        source={{ uri: props.item.image ? props.item.image :"https://image.shutterstock.com/image-vector/no-image-available-sign-absence-260nw-373244122.jpg" }}
      />
      <View style={styles.text_container}>
        <Text style={styles.title}>{props.item?.items[0].product.displayName}</Text>
        <Text style={styles.label}>Sold by {props.item.store.displayName}</Text>
        <Text style={styles.title1}>₹ {props.item?.items[0].price}</Text>
        <Text style={styles.count}>{props.item?.items[0].quantity === 1 ? `${props.item?.items[0].quantity} Item` :`${props.item?.items[0].quantity} Items`}</Text>

      </View>



    </TouchableOpacity>

  )
})
const styles = StyleSheet.create({

  item: {
    padding: 10,
    marginVertical: 4,
    marginHorizontal: 16,
    borderColor: "#EEEEEE",
    borderWidth: 1,
    height: height / 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
    flex: 1

  },
  title: {
    fontSize: 16,
    lineHeight: 25,
    fontFamily:"Mulish-Regular",
  },
  title1:{
    fontSize: 17,
    lineHeight: 30,
    fontFamily:"Mulish",
  },
  label: {
    fontSize: 15,
    lineHeight: 20,
    paddingVertical:2,
    color: "grey",
    fontSize:12,
    fontFamily:"Mulish-Regular"
  },
  count: {
    alignSelf: "flex-end",
    fontFamily: "Mulish"
  },
  tinyLogo: {
    // width: "35%",
    height: "100%",
    flex: 0.35
  },
  text_container: {
    flex: 0.62,

  }
});