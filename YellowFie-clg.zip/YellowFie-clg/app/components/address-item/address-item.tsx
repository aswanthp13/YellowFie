import React ,{useState} from "react"
import { View, Text,StyleSheet,TouchableOpacity,Image } from "react-native"
import { Screen,} from ".."
import { color } from "../../theme"




export const AddressItem = (props) =>{


  const [shouldShow, setShouldShow] = useState(true);

 

  return (
    <Screen style={styles.ROOT} preset="scroll">
      <View style={styles.mainview}>
          

          <View style={{flexDirection:"column",left:20,}}>
             <Text style={{fontWeight:"bold",lineHeight:20.08}}>{props.data.name}</Text>
             <Text style={styles.Text1}>{props.data.addressline1}</Text>
             <Text style={styles.Text1}>{props.data.addressline2}</Text>
             <Text style={styles.Text1}>{props.data.city}</Text>
             <Text style={styles.Text1}>{props.data.state}</Text>
          </View>


         
      
          
          <View style={{flexDirection:"column",left:160,}}>
            
              <TouchableOpacity  
                  onPress={() => setShouldShow(!shouldShow)}      
                  style={styles.checkbox}
                                >
              
              {shouldShow?(
                <View style={styles.touchableinactive}>
                 <Image style={styles.inactiveicon} source={require("./inactive.png")}></Image>
                </View>
               ):( 
                 <View style={styles.touchableactive}>
                 <Image style={styles.activeicon} source={require("./active.png")}></Image>
                 </View>
               )}

              </TouchableOpacity>
            
             <Text style={{lineHeight:20.08,textAlign:"right",fontWeight:"bold", top:30 ,right:-10}}>{props.data.totalamount}</Text>
          </View>
         
      </View>
    </Screen>
  )
}

const styles = StyleSheet.create({

  ROOT:{
      backgroundColor: color.palette.white,
      flex: 1,
      alignItems:"center",
      justifyContent:"center",
  },
  Text1:{
    lineHeight:20.08
  },
  
  mainview:{
    borderWidth:1,
    borderColor:"black", 
    flexDirection:"row" ,
    height:149,
    width:330,
    margin:20,
    alignItems:"center"
  },
  checkbox:{
    top:-30,
    right:-30,
    // backgroundColor:"#fff",
    textAlign:"right",
    alignItems:"center",
    justifyContent:"center",
    height:21,
    width:21,
    borderRadius:100,
    // borderColor:"black",
    // borderWidth:1,
    
  },
  inactiveicon:{
    alignItems:"center",
    height:9.38,
    width:12.32,
    borderRadius:100,
    backgroundColor:"#fff"
  },
  activeicon:{
    alignItems:"center",
    height:9.38,
    width:12.32,
    borderRadius:100,
    backgroundColor:"#2eb82e"
  },
  touchableactive:{
  
    backgroundColor:"#2eb82e",
    justifyContent:"center",
    height:"100%",
    width:"100%",
    borderRadius:100,
    alignItems:"center",
    borderColor:"black",
    borderWidth:1,
    
    
  },
  touchableinactive:{
   
    backgroundColor:"#fff",
    justifyContent:"center",
    height:"100%",
    width:"100%",
    borderRadius:100,
    alignItems:"center",
    borderColor:"black",
    borderWidth:1,
    
  },
     
  })
