import React, { useState } from 'react'


import { ViewStyle, TextStyle,Image ,ImageStyle, View,ScrollView,Alert, TouchableOpacity,TextInput,StyleSheet } from 'react-native'
import { Screen, Text, Header } from "../../components"

// import { useStores } from "../../models"
import { color, spacing, typography } from "../../theme"
import {SlickSlider} from "../../components"
import { Fontisto } from '@expo/vector-icons';


const ROOT: ViewStyle = {
    backgroundColor: color.palette.white,
     flex: 1,
  }
  
  const mainContainer: ViewStyle = {
   
    // padding:20,
    marginRight:20,
    marginLeft:20,
  }
  const TEXT: TextStyle = {
    color: color.palette.black,
    fontFamily: typography.primary,
  }
  
  const BOLD: TextStyle = { fontWeight: "bold" }
  
  const CONTENT: TextStyle = {
    ...TEXT,
    // color: "#BAB6C8",
    fontSize: 12,
    lineHeight: 15,
    // marginBottom: spacing[5],
    fontWeight:"bold",
  
  
  }
  
//   const HEADER: TextStyle = {
//     paddingTop: spacing[3],
//     paddingBottom: spacing[5] - 1,
//     paddingHorizontal: 0,
//     backgroundColor: color.palette.white,
//     marginLeft:20,
    
    
//   }
  
//   const HEADER_TITLE: TextStyle = {
//     ...BOLD,
//     fontSize: 12,
//     lineHeight: 15,
//     textAlign: "center",
//     letterSpacing: 1.5,
//     color: color.palette.black,
//   }

  const TEXTSTYLE1: TextStyle = {
      color:"#000000",
      fontSize:12,
      lineHeight:15,
      textTransform: 'lowercase'
  }
  const TEXTSTYLE2: TextStyle = {
   ...TEXTSTYLE1,
   ...BOLD,
}

export const FeedItem = (props) => {


    // const navigation = useNavigation()
    // const goBack = () => navigation.goBack()
    const viewcomments = () => {Alert.alert("view comments")}
    const addheart = () => {
      Alert.alert("add ")
      // setCount(count + 1)
    }
    const addcomment = () => {Alert.alert("add comment ")}
    const addtag = () => {Alert.alert("add tag")}


  


        return (
            <Screen style={ROOT} preset="scroll">
      
           <View style={mainContainer}>
               
               <View style={{flexDirection:"row", }}>
                 <Image  source={require('./icontop.png')} style={{height:50,width:50,}}></Image>   
                  <View style={{flexDirection:"column",}}>
        
        
                     <Text style={{color:"black",}} >{props.data.storename}</Text>
                     
                     <Text style={{color:"black",fontSize:10}} >{props.data.location},{props.data.city} </Text>
                  </View>
                </View >
               
               <View style={{alignContent:"center", }}>
                <SlickSlider />
                {/* <SlickSlider images={images} /> */}
                </View>
                
                <View style={{flexDirection:"row", marginTop:10}}>
            
                  <TouchableOpacity style={{marginRight:8}} onPress={addheart} >
                     <Fontisto name="heart-alt" size={24} color="black" />
                  </TouchableOpacity>    

                  <TouchableOpacity style={{marginLeft:8}} onPress={addcomment} >     
                      <Fontisto name="comment" size={24} color="black" />
                   </TouchableOpacity> 

                   <TouchableOpacity style={{right:-220}} onPress={addtag} > 
                      <Fontisto name="favorite" size={24} color="black" />
                   </TouchableOpacity>

                </View>
        
                <View style={{flexDirection:"column", marginTop:10}}>

                   <Text  style={CONTENT} >{props.data.count}</Text>
                   <Text  style={TEXTSTYLE1} ><Text style={TEXTSTYLE2}>{props.data.storename} </Text> {props.data.productname} </Text>  
                   <Text  style={{color:"#B4B4B4",fontSize:12,lineHeight:15.06, fontWeight:"400",}} onPress={viewcomments} >View {props.data.comments}  comments </Text> 
                   <TextInput placeholder = "Add a comment..." placeholderTextColor = "#B4B4B4"
                     style={styles.TextInputStyles}
                     underlineColorAndroid='transparent'
                   />
                </View>
               
           </View>
        
          
           
           </Screen>

        )
    }

    const styles = StyleSheet.create({

        TextInputStyles:{
            borderColor:"#EEEEEE",
            color:"black",
            borderWidth: 1,
            width:"100%",
            height:32,
            lineHeight:15.06,
            textAlign:"left",
        },
        
        
           
        })