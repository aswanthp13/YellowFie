import * as React from "react"
import { View, ViewStyle, StyleSheet, TouchableOpacity, Image } from "react-native"
import { observer } from "mobx-react-lite"
// import { color, typography } from "../../theme"
import { Text } from "../"
// import Icon from 'react-native-vector-icons/Ionicons'

const CONTAINER: ViewStyle = {
  justifyContent: "center",
  width: 330,
}

// const TEXT: TextStyle = {
//   fontFamily: typography.primary,
//   fontSize: 14,
//   color: color.primary,
// }

export interface PlusbuttonProps {
  image?: any
 /**
   * An optional style override useful for padding & margin.
   */
  style?: ViewStyle
  }

/**
 * Describe your component here
 */
export const Plusbutton = observer(function Plusbutton(props: PlusbuttonProps) {
  // export function Plusbutton(props: PlusbuttonProps) {  
  const { style } = props
    let imgUrl = props.image ? { uri: props.image } : require("../../../assets/add.png")

  return (
    <View style={[CONTAINER, style]}>
      <TouchableOpacity style={styles.btn} disabled>
        <Image source={imgUrl} style={styles.img} />
        <Text style={{ lineHeight:20.08,marginTop:10 }}>Image</Text>
      </TouchableOpacity>
    </View>
  )
})
  // }

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    padding: 20
   },
  img: {
    // position: "absolute",
    // top: 120,
    // left:136,
    width: 68,
    height:68,
  },
  btn: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0.5,
    borderColor: '#B4B4B4',
    height: 320,
    width:320
  }
})