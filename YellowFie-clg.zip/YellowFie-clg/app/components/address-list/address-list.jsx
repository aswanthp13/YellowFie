import React, { useState, useEffect } from "react"
import { TextStyle, View, ScrollView, SafeAreaView } from "react-native"
import { observer } from "mobx-react-lite"
import { color, typography } from "../../theme"
import { Button } from "../../components"

import { AddressItem } from "../address-item/address-item"


const DEMO = {
  paddingVertical: 10,
  paddingHorizontal: 4,
  backgroundColor: "#ffff",
  elevation: 3,
  marginVertical: "4%"
}

const DEMO_TEXT = {
  fontFamily: "Mulish",
  fontSize: 16,
  letterSpacing: 1,
  color: "black"
}


/**
 * Describe your component here
 */
export const AddressList = observer(function AddressList(props) {

  const [data, setData] = useState(props.data)

  const defaultHandler = (val) => {

    // call default api

    // then call get api

  }


  return (
    <View>
      <ScrollView>
        {data && data.map((el, index) => {
          return <AddressItem key={index}
            data={el}
            defaultHandler={defaultHandler} />
        })}

      </ScrollView>
      <Button style={DEMO}
        textStyle={DEMO_TEXT}
        tx="AddressList.title"
      />
    </View>
  )
})
