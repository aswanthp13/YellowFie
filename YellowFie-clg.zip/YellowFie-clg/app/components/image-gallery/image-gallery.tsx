import  React, { useState,useEffect }  from "react"
import { View,FlatList,StyleSheet,Text,Dimensions,ActivityIndicator} from "react-native"
import {ImageItemData} from "../../components"

var width = Dimensions.get('window').width;
var height =width/3

export const ImageGallery = (props) => {

  const [data,setData]=useState([])
  const [isLoading,setisLoading]=useState(false)
  const [pageCurrent,setpageCurrent]=useState(1)

    useEffect(() => {
      console.log("useEffect PageCurrent",pageCurrent)
      setisLoading(true)
      getData()
      return () => {
       
      }
    }, [pageCurrent])
   const getData = async() =>{
      
       const apiURL=props.source+pageCurrent
       fetch(apiURL).then((res)=>res.json())
       .then((resJson)=>{
           setData(data.concat(resJson))
           setisLoading(false)
       })
   }

   const renderItem=({item})=>{
    return (
      <View style={styles.ItemRow}>
         <ImageItemData source={item}/>
      </View>        
  )
}

const renderFooter=()=>{
  return (
    isLoading?
    <View style={styles.loader}>
     <ActivityIndicator size="large" color = '#bc2b78'/>
    </View>:null        
)
}

const handleLoadMore=()=>{
  // Alert.alert("hi")
   setpageCurrent(pageCurrent+1)
   setisLoading(true)
}

   return(
    <FlatList 
    style={styles.container} 
    data={data}
    numColumns={3}
    renderItem={renderItem}
    keyExtractor={(item,index) => index.toString()}
    ListFooterComponent={renderFooter}
    onEndReached={handleLoadMore}
    onEndReachedThreshold={0.01}
    />
)
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EEEEEE',
    marginTop: 20,
  },
  
  box: {
    borderBottomColor:"red",
    borderBottomWidth:1,
    // marginBottom:10,
  },
  ItemRow:{
   borderBottomColor:"#ccc",
   borderBottomWidth:1,
  //  marginBottom:10
  },
  Itemimage:{
    width:width/3, height:height ,resizeMode:"cover"
  },
  ItemText:{
    fontSize:16,textAlign:"center"
  },
  loader:{
    marginTop:10,
    alignItems:"center",
  }
  
});