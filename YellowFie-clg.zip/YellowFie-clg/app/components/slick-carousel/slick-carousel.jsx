import React, { useEffect, useState } from "react"
import { StyleSheet, Text, View, Image, ScrollView, Dimensions } from "react-native"
import { observer } from "mobx-react-lite"
import { color, typography, spacing } from "../../theme"

const CONTAINER = {
  // justifyContent: "center",
  // paddingHorizontal: spacing[4],
  flex: 1
}
const { width } = Dimensions.get("window");
const height = width

const TEXT = {
  fontFamily: typography.primary,
  fontSize: 14,
  color: color.primary,
}






/**
 * Describe your component here
 */
export const SlickCarousel = observer(function SlickCarousel(props) {
  const [pics, setPics] = useState([""])
  useEffect(() => {
    console.log("pics..", pics)

    setPics(props.attachments)

  }, props.attachments)

  // const pics = props.attachments
  const [active, setActive] = useState(0)
  const change = ({ nativeEvent }) => {
    const slide = Math.ceil(nativeEvent.contentOffset.x / nativeEvent.layoutMeasurement.width);
    console.log("slide", slide)
    if (slide !== active) {
      setActive(slide)
    }

  }


  return (
    <View style={styles.container}>


      <ScrollView
        style={styles.scroll}
        pagingEnabled
        horizontal={true}
        showsHorizontalScrollIndicator={false}
        onScroll={change}
      >
        {pics && pics.length > 0 ? pics.map((item, index) => {
          return (
            <Image
              key={index}
              source={{ uri: item }}
              style={styles.image}
            />

          )

        }) :
          <Image
            source={{ uri: "https://1080motion.com/wp-content/uploads/2018/06/NoImageFound.jpg.png" }}
            style={styles.image}
          />
        }
      </ScrollView>
      <View style={styles.slider}>

        {pics && pics.length > 0 && pics.map((i, k) => {
          return <Text key={k} style={k === active ? styles.pagingActiveText : styles.pagingText}>⬤</Text>

        })}
      </View>
    </View>
  )
})
const styles = StyleSheet.create({
  container: {
    // width, height
   
  },
  scroll: {
    width, height
  },
  image: { width:width, height, resizeMode: "cover" },
  slider: { flexDirection: "row", position: "absolute", bottom: "-5%", alignSelf: "center" },
  pagingText: {
    color: "#D3D3D3",
    margin: 3
  },
  pagingActiveText: {
    color: "#A9A9A9",
    margin: 3
  }
})