import  React,{useState} from "react"
import { View, ViewStyle } from "react-native"
import {ImageRowItem} from "../../components"

  export const ImageRow=(props)=> {
 
    const [data]=useState([
        {uri:"https://bit.ly/36nAlLg"},
        {uri:"https://bit.ly/2KSqEMt"},
        {uri:"https://bit.ly/2HViVMy"},
        
        
    ])

  return (
    <ImageRowItem source={data}/>
   
  )

  }
