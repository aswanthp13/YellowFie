import  React from "react"
import { View, ViewStyle } from "react-native"
import {ImageItemData} from "../../components"

const CONTAINER: ViewStyle = {
  flexDirection:"row",
}

  export interface ImageRowProps {
     style?: ViewStyle
  }

  export const ImageRowItem=(props)=> {
  return (
 
    <View style={CONTAINER}> 
    {props.source.map((el) => {return   (

 <View style={{flexDirection:"column"}}>
     <ImageItemData source={el} />
   </View>
     )}) }
   
   </View>
  )

  }
