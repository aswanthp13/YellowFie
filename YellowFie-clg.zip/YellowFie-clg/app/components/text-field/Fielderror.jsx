import React from 'react'
import { TextInput, StyleSheet, View, Text } from "react-native";
function Fielderror(props) {
    return (
        <View>
            {props.text ? (
                <View style={styles.alert}>
                    <Text style={styles.error1}>{props.text}</Text>
                </View>
            ) : null}

        </View>
    )
}

export default Fielderror
const styles = StyleSheet.create({
    error1: {
        color: "red",
        justifyContent: "center",
        alignItems: "center",
    },
    alert: {
        marginLeft: 10
    },
    title: {
        marginTop: 8,
        marginBottom: 8
    }
});