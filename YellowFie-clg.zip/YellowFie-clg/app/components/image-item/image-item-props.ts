import { ImageStyle } from "react-native"
// import { WallpaperPresets } from "./wallpaper.presets"

export interface ImageProps {
  /**
   * An optional style override useful for padding & margin.
   */
  style?: ImageStyle

  
  backgroundImage?: string

  // source:any

  
}
