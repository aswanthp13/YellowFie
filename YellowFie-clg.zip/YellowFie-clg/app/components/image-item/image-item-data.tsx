import React,{useState,useEffect} from 'react'
import { View,Image,Dimensions,ActivityIndicator,ImageBackground } from "react-native"

var width = Dimensions.get('window').width;
var height =width/3
// var Screenheight=Dimensions.get('window').height
export const ImageItemData=(props)=> {
  const[animating,setanimate]=useState(true)
  const [shouldShow, setShouldShow] = useState(true)
    // const[setanimate]=useState(false)
    useEffect(()=>{
          setTimeout(()=>setanimate(false),3000)
    })
    useEffect(()=>{
      setTimeout(()=>setShouldShow(false),3005)
})

    
  return (
     <View style={{alignItems:"center",justifyContent:"center",}}>
       {shouldShow ?
 
         <View style={{alignItems:"center",justifyContent:"center", width:width/3, height:height,backgroundColor:"#fff"}}>
         <ImageBackground source={{uri:"https://bit.ly/3a8lW7E"}} style={{height:"100%",width:"100%",justifyContent:"center",alignItems:"center"}}>
         <ActivityIndicator
               animating = {animating}
               color = '#bc2b78'
               size = "large"
               style = {{justifyContent: 'center', alignContent: 'center',}}></ActivityIndicator>
         </ImageBackground>
          </View> 
         
        :
    <Image source = {{uri:props.source.url}} style = {{ width:width/3, height:height,}}/>
       }
    </View>
  )
}